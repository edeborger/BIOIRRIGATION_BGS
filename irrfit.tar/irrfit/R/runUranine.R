
# ==============================================================================
# Helper functions
# ==============================================================================
## the default parameter values
checkParms <- function(parms = list(), novalue = NULL) {
  #DEFAULT PARAMETERS
  PP <-list(
    
    pumpSurfRate    = 100,       # pumping (piston) rate  cm3/cm2/hour  [cm hour-1]
    pumpSurfDepth   = 2.0,       # Depth of fully irrigated layer (cm) - was xbm
    pumpSurfAtt     = 2,         # /cm, Exponential attenuation coefficient -  was xL

    pumpInjectRate  = 0.0,       # Pumping (piston) rate of cavity pumper cm3/cm2/hour  [cm hour-1]
    pumpInjectDepth = 2,         # Mean depth of injection layer (cm)
    pumpInjectSd    = 1.0,       # Standard deviation of injection layer thickness (cm)
    
    pumpOtherRate  = 0.0,        # Other type of irrigation cm3/cm2/hour  [cm hour-1]

    eqAds  = 0.4,                # Adsorption coefficient uranine      [cm3 x g-1], range = 0.067 - 1.29
    kAds   = 3,                  # Kinetic rate cte adsorption         [hour-1], range = 0.001 - 0.02
    decay  = 0.0,                # first-order decay rate
        
    #Model/core geometry
    hOw    = 15,                 # Height overlying water column       [cm]
    hSed   = 15,                 # Height sediment column              [cm]
    area   = 30,                 # Core surface area [cm2]             [cm2]
    dBL    = 0.05,               # cm - height of diffusive boundary layer [cm]
    dx.1   = 0.05,               # cm - height of initial sediment layer [cm]

    #Sediment parameters
    dens      = 2.6,             # Density sediment                    [g.cm-3]
    diffCoeff = 0.015,           # Uranine diffusion coefficient       [cm2.hour-1] (Francesc manuscript ==> Mortensen et al 2004)  #Karline: was <-
    porosity  = 0.5,             # Porosity sediment                   [/]
    iniConcOW = 1                # Uranine in overlying water to begin [ng.cm-3]
  )
  
  
  ## check parameter inputs
  if (length(parms)) {
    nms <- names(PP)
    nmsparms <- names(parms)
    if (length (NM <- which(nmsparms %in% novalue))) {
       warning("parameter ", nmsparms[NM], " should not be given a value - it is ignored")
       parms <- parms[-NM]
    }  
    PP[(namc <- names (parms))] <- parms
    if (length(noNms <- namc[!namc %in% nms]) > 0)
      warning("unknown names in parms: ", paste(noNms, collapse = ", "))
  }
  as.list(PP)
}

# ==============================================================================
# Retrieving values
# ==============================================================================

parms.Uranine <- function (out = NULL)  {
  ParmsUnits <- c("cm hour-1", "cm", "/cm", "cm hour-1", "cm", "cm", "cm hour-1",
                  "cm3 x g-1", "hour-1", "/d", "cm", "cm", "cm","cm2", "cm", 
                "g.cm-3", "cm2.hour-1", "-", "ng.cm-3")
  if (is.null(out))
    data.frame(Parms = unlist(checkParms()), Units = ParmsUnits)
  else
    data.frame(Parms = attributes(out)$parms, Units = ParmsUnits)
}

grid.Uranine <- function (out)  
  attributes(out)$grid

gridext.Uranine <- function (out)  
  attributes(out)$grid.ext

irrigation.Uranine <- function (out)  {
  list(Surface = attributes(out)$irrigation.Surf,
       Inject  = attributes(out)$irrigation.Inject,
       Other   = attributes(out)$irrigation.Other)
}

# ==============================================================================
# Functions to create depth-decaying irrigation profiles (unscaled)
# ==============================================================================
f.SurfIrrigation <- function(x, depth, att, scale = TRUE) {
  Fun <- pmin(1, exp(-att * (x - depth)))
  if (scale) 
     Fun <- Fun /sum(Fun)
  return (Fun)
}

# Functions to create gaussian-type irrigation profiles (unscaled)
f.InjectIrrigation <- function(x, depth, sd, scale = TRUE) {
  Fun <- exp(-(x-depth)^2 /sd^2)
  if (scale) 
    Fun <- Fun /sum(Fun)
  return (Fun)
}

# ======================================================================================
# Main function to run the uranine model
# ======================================================================================
run.Uranine <- function(parms = list(), 
                       hours = 1, times = seq(from = 0, to = hours, length.out = 100),
                       f.pumpOther  = NULL,   # function that describes irrigation profile
                       t.pumpSurf   = NULL,  # time-varying pumpingrate - if NULL:ct
                       t.pumpInject = NULL, 
                       t.pumpOther  = NULL,   # time-varying pumpingrate - if NULL:ct
                       constantBW = FALSE, 
                       yini = NULL, ...) {
  Out <- run.Subst (parms = parms, times = times,
              f.pumpOther = f.pumpOther,  t.pumpSurf  = t.pumpSurf,  
              t.pumpInject = t.pumpInject, t.pumpOther  = t.pumpOther,  
              novalue = "decay", Ads = TRUE, ctBW = constantBW, yini = yini, ...) 
  #outnames  = c("Fup", "Fdown", "IrrigationFlux", "DiffusionFlux", "TotalDecay", 
  #              "TotalAdsorption", "UrOWtot", "UrPWtot", "UrAdstot",  "UrSed", "UrAll", 
  #              "pumpSurf", "pumpInject", "pumpOther") 
  return(Out)    
}

# ======================================================================================
# Main function to run the oxygen/Bromide model
# ======================================================================================
run.Tracer <- function(parms = list(), 
                        hours = 1, times = seq(from = 0, to = hours, length.out = 100),
                        f.pumpOther  = NULL,   # function that describes irrigation profile
                        t.pumpSurf   = NULL,  # time-varying pumpingrate - if NULL:ct
                        t.pumpInject = NULL, 
                        t.pumpOther  = NULL,   # time-varying pumpingrate - if NULL:ct
                        constantBW = FALSE, yini = NULL, ...) {
  Out <- run.Subst (parms = parms, times = times,
                    f.pumpOther = f.pumpOther,  t.pumpSurf  = t.pumpSurf,  
                    t.pumpInject = t.pumpInject, t.pumpOther  = t.pumpOther,  
                    novalue = c("kAds", "eqAds"), Ads = FALSE, ctBW = constantBW, yini = yini, ...) 
  return(Out)    
}


# ======================================================================================
# Main function to run A TRACER model
# ======================================================================================
run.Subst <- function(parms = list(), 
                        hours = 1, times = seq(from = 0, to = hours, length.out = 100),
                        f.pumpOther  = NULL,   # function that describes irrigation profile
                        t.pumpSurf   = NULL,  # time-varying pumpingrate - if NULL:ct
                        t.pumpInject = NULL, 
                        t.pumpOther  = NULL,   # time-varying pumpingrate - if NULL:ct
                        novalue = NULL,
                        Ads = TRUE,
                        ctBW = FALSE, yini = NULL,
                        ...) {
  Parms <- checkParms(parms, novalue = novalue)
  with(Parms,{
    
    # sediment compartments - upper slice thickness is imposed (dx.1) and 
    # also the thickness of the diffusive boundary layer (dBL)
    # First layer is the diffusive boundary
    N   <- 50
    if (dBL <= 0) dBL <- dx.1
    
    G       <- setup.grid.1D(x.up = -dBL, dx.1 = dx.1, N = N, L = hSed)
    dx      <- G$dx
    #    dx      <- rep(hSed/N, N)
    
    dxint   <- G$dx.aux
    x       <- G$x.mid
    x.ext   <- c(-dBL, x)
    
    intpor  <- c(1,rep(porosity, times = N))
    por     <- c(1,rep(porosity, times = N-1))
    Diffvec <- diffCoeff*intpor         # effective diffusion coefficient

    # irrigation
    npump      <- 3                     # two irrigation methods
    
    irrprofile1 <- f.SurfIrrigation  (x, pumpSurfDepth, pumpSurfAtt)
    Rescale1    <- sum(irrprofile1*dx*por)
    
    irrprofile2 <- f.InjectIrrigation(x, pumpInjectDepth, pumpInjectSd)
    Rescale2    <- sum(irrprofile2*dx*por)
    
    if (! is.null(f.pumpOther)) {
      if (! is.function(f.pumpOther))
        stop ("'f.pumpOther' should be a function") 
      if (pumpOtherRate == 0 & is.null(t.pumpOther))
        warning("'f.pumpOther' with zero irrigation ('pumpOtherRate'=0, 't.pumpOther' = NULL and will have no effect")
      
      irrprofile3 <- f.pumpOther(x)
      Rescale3    <- sum(irrprofile3*dx*por)
    } else {
      irrprofile3 <- rep(0, N)
      Rescale3    <- 1
    }  
    irrprofile <- cbind(irrprofile1/Rescale1, irrprofile2/Rescale2, irrprofile3/Rescale3)
    
    if (is.null(t.pumpSurf))
      t.pumpSurf   <- cbind(time = range(times), 
                            rate = pumpSurfRate)
    
    if (is.null(t.pumpInject))
      t.pumpInject <- cbind(time = range(times), 
                            rate = pumpInjectRate)
    
    if (is.null(t.pumpOther))
      t.pumpOther   <- cbind(time = range(times), 
                             rate = pumpOtherRate)
    
    if (Ads) {
    #Initial conditions
      if (is.null(yini))
      yini  <- c(UrOW = iniConcOW, UrPW  = rep(0, N), 
                 AdsOw = 0,      UrAds = rep(0, N)) 
     
      initparms <- c(kAds, eqAds, decay, dens, hOw, area, iniConcOW, x, dx, dxint, 
                     por, intpor, Diffvec, irrprofile)
    
      outnames  <- c("Fup", "Fdown", "totIrr", "totDiff", "totalDecay", "totalAdsorption", 
                     "UrOWtot", "UrPWtot", "UrAdstot",  "UrSed", "UrAll", 
                     "pumpSurf", "pumpInject", "pumpOther") 
      if (ctBW) {
        modelfunc <- "urmod"
        if (is.null(yini))
          yini  <- c(UrPW  = rep(0, N), 
                   UrAds = rep(0, N)) 
        else 
          names(yini) <- c(rep("UrPW", N), rep("UrAds", N))  
      } else {
        modelfunc <- "urmodbw"
        if (is.null(yini))
          yini  <- c(UrOW = iniConcOW, UrPW  = rep(0, N), 
                     AdsOw = 0,        UrAds = rep(0, N)) 
        else
          names(yini) <- c("UrOW", rep("UrPW", N), "AdsOW", rep("UrAds", N))  
          
      }
      
      LL <- list(...)
      if (is.null(LL$atol))
        LL$atol <- 1e-12
      if (is.null(LL$rtol))
        LL$rtol <- 1e-8
      
      if (any(is.infinite(times ))) {
        Forcs <- c(mean(t.pumpSurf  [,2]), 
                   mean(t.pumpInject[,2]),
                   mean(t.pumpOther [,2]))
      
        out <- do.call("steady.1D", c(list(func = modelfunc, y = yini, times = c(0, Inf), 
                         parms = initparms, initfunc = "initur", initforc = "urforc",
                         names = c("UrPW", "UrAds"), nspec = 2, dllname = "irrfit", 
                         forcings = Forcs, outnames = outnames, 
                         nout = length(outnames), method = "runsteady"), LL))
      } else
      
        out <- do.call("ode.1D", c(list(func = modelfunc, y = yini, times = times, 
                      parms = initparms, initfunc = "initur", initforc = "urforc",
                      names = c("UrPW", "UrAds"), nspec = 2, dllname = "irrfit", 
                      forcings = list(t.pumpSurf, t.pumpInject, t.pumpOther), 
                      method = "lsodes", outnames = outnames, nout = length(outnames)), LL))

      } else { # NO adsorption
      if (ctBW) {
        modelfunc <- "tracermod"
        if (is.null(yini))        
          yini  <- c(PW = rep(0, N))
        else 
          names(yini) <- rep("PW", N)
      } else {
        modelfunc <- "tracermodbw"
        if (is.null(yini))        
          yini  <- c(OW = iniConcOW, PW  = rep(0, N)) 
        else 
          names(yini) <- c("OW", rep("PW", N))  
      }

      initparms <- c(decay, hOw, area, iniConcOW, x, dx, dxint, 
                     por, intpor, Diffvec, irrprofile)
      
      outnames  <- c("Fup", "Fdown", "totIrr", "totDiff", "totalDecay", 
                     "OWtot", "PWtot", "All", 
                     "pumpSurf", "pumpInject", "pumpOther") 
      
      if (any(is.infinite(times ))) {
        Forcs <- c(mean(t.pumpSurf  [,2]), 
                   mean(t.pumpInject[,2]),
                   mean(t.pumpOther [,2]))
        
        out <- steady.1D(func = modelfunc, y = yini, times = c(0, Inf), 
                         initpar = initparms, initfunc = "inittracer", initforc = "tracerforc",
                         names = "Conc", nspec = 1, dllname = "irrfit", 
                         forcings = Forcs, outnames = outnames, atol = 1e-12, rtol = 1e-12,
                         nout = length(outnames), method = "runsteady", ...)
      } else
        
        out <- ode.1D(func = modelfunc, y = yini, times = times, 
                      initpar = initparms, initfunc = "inittracer", initforc = "tracerforc",
                      names = c("Conc"), nspec = 1, dllname = "irrfit", 
                      forcings = list(t.pumpSurf, t.pumpInject, t.pumpOther), 
                      atol = 1e-12, rtol = 1e-12, 
                      method = "lsodes", outnames = outnames, nout = length(outnames), ...)
      
    }  # en nog adsorbed
    
    
    attr(out, "grid")              <- x               # mean of sediment slices
    attr(out, "grid.ext")          <- x.ext           # including boundary layer
    attr(out, "irrigation.Surf")   <- irrprofile[,1]* mean(t.pumpSurf  [,2])
    attr(out, "irrigation.Inject") <- irrprofile[,2]* mean(t.pumpInject[,2])
    attr(out, "irrigation.Other")  <- irrprofile[,3]* mean(t.pumpOther [,2])
    attr(out, "parms")   <- unlist(Parms)
    out
  })
}

